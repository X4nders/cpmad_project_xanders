// restaurant.dart

class Restaurant {
  String uid;
  String name;
  String description;
  String image;
  List<MenuItem> menu;

  Restaurant({
    this.uid,
    this.name,
    this.description,
    this.image,
    this.menu = const [],
  });

  Restaurant.fromMap(Map<String, dynamic> data) {
    uid = data['uid'];
    name = data['name'];
    description = data['description'];
    image = data['image'];
    menu = data['menu'];
  }

  Map<String, dynamic> toMap() {
    return {
      'uid': uid,
      'name': name,
      'description': description,
      'image': image,
      'menu': menu
    };
  }
}

class MenuItem {
  String uid;
  String name;
  String description;
  double price;
  int _quantity; // use a private variable

  MenuItem({
    this.uid,
    this.name,
    this.description,
    this.price,
    int quantity = 0,
  }) : _quantity = quantity;

 // Getter and Setter for quantity
  int get quantity => _quantity;

  set quantity(int newQuantity) {
    _quantity = newQuantity;
  }

  MenuItem.fromMap(Map<String, dynamic> data) {
    uid = data['uid'];
    name = data['name'];
    description = data['description'];
    price = data['price'];
  }

    Map<String, dynamic> toMap() {
    return {
      'uid': uid,
      'name': name,
      'description': description,
      'price': price
    };
  }
}

class Cart {
  static List<MenuItem> items = [];  // Use MenuItem from restaurant.dart
}

class CartService {
  static List<MenuItem> items = [];

  static addItem(MenuItem item) {
    items.add(item);
  }

  static removeItem(MenuItem item) {
    items.remove(item);
  }

  static List<MenuItem> getItems() {
    return items;
  }
}
