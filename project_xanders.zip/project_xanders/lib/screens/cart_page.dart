import 'package:flutter/material.dart';
import 'package:project_xanders/model/restaurant.dart'; // Import the cart model and service

class CartPage extends StatefulWidget {
  @override
  _CartPageState createState() => _CartPageState();
}

class _CartPageState extends State<CartPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Cart')),
      body: Column(
        children: <Widget>[
          Expanded(
            child: ListView.builder(
              itemCount: Cart.items.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text(Cart.items[index].name),
                  subtitle: Text(Cart.items[index].description),
                  trailing: Text('\$${Cart.items[index].price.toString()}'),
                );
              },
            ),
          ),
          Container(
            padding: EdgeInsets.all(16.0),
            child: ElevatedButton(
              onPressed: _proceedToCheckout,
              child: Text('Proceed to Checkout'),
            ),
          ),
        ],
      ),
    );
  }
  double calculateTotal() {
  double total = 0.0;
  for (var item in Cart.items) {
    total += item.price;
  }
  return total;
  }
  void _proceedToCheckout() {
    double totalPrice = calculateTotal();

    // Check if cart is empty
    if (Cart.items.isEmpty) {
      print("The cart is empty. Add items before checking out.");
      return;
    }
    bool paymentProcessed = processPayment(totalPrice);

    if (paymentProcessed) {
      // If payment was successful, clear the cart and inform the user
      Cart.items.clear();
      print("Checkout successful! Thank you for your purchase.");
    } else {
      print("Payment failed. Please try again.");
    }
  }

  bool processPayment(double amount) {
    print("Processing payment of \$${amount.toStringAsFixed(2)}...");
    return true;
  }

}
