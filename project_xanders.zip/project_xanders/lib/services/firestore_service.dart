import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:project_xanders/model/restaurant.dart';

class FirestoreService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<void> addRestaurant(Restaurant restaurant) async {
    DocumentReference restaurantRef = await _firestore.collection('restaurants').add({
      'name': restaurant.name,
      'description': restaurant.description,
      'image': restaurant.image,
    });

    if (restaurant.menu != null) {
      for (var menuItem in restaurant.menu) {
        restaurantRef.collection('menu').add({
          'name': menuItem.name,
          'description': menuItem.description,
          'price': menuItem.price,
        });
      }
    }
  }

  Future<List<Restaurant>> fetchRestaurants() async {
    QuerySnapshot restaurantSnapshot = await _firestore.collection('restaurants').get();

    List<Restaurant> restaurants = [];

    for (var restaurantDoc in restaurantSnapshot.docs) {
      List<MenuItem> menu = [];
      var menuSnapshot = await restaurantDoc.reference.collection('menu').get();

      for (var menuItemDoc in menuSnapshot.docs) {
        menu.add(MenuItem(
          name: menuItemDoc['name'],
          description: menuItemDoc['description'],
          price: menuItemDoc['price'].toDouble(),
        ));
      }

      restaurants.add(Restaurant(
        name: restaurantDoc['name'],
        description: restaurantDoc['description'],
        image: restaurantDoc['image'],
        menu: menu,
      ));
    }

    return restaurants;
  }
}
